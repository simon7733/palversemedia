import { NextRequest, NextResponse } from 'next/server'

// This would normally be connected to a database
// For now, we'll store in memory (this will reset on server restart)
let jobApplications: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Add timestamp and ID
    const application = {
      id: Date.now().toString(),
      ...body,
      createdAt: new Date().toISOString(),
      status: 'pending'
    }
    
    jobApplications.push(application)
    
    console.log('New job application:', application)
    
    return NextResponse.json({ 
      success: true, 
      message: 'Application submitted successfully',
      id: application.id 
    })
  } catch (error) {
    console.error('Error processing job application:', error)
    return NextResponse.json(
      { success: false, message: 'Error processing application' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({ 
    success: true, 
    applications: jobApplications 
  })
}