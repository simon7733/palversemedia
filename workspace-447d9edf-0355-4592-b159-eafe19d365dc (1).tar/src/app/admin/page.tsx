"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, Briefcase, Mail, Phone, Calendar, Eye, Download } from "lucide-react"

interface Application {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  city: string
  createdAt: string
  status: string
  [key: string]: any
}

export default function AdminPage() {
  const [influencerApps, setInfluencerApps] = useState<Application[]>([])
  const [jobApps, setJobApps] = useState<Application[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchApplications()
  }, [])

  const fetchApplications = async () => {
    try {
      const [influencerRes, jobRes] = await Promise.all([
        fetch('/api/influencer-application'),
        fetch('/api/job-application')
      ])
      
      const influencerData = await influencerRes.json()
      const jobData = await jobRes.json()
      
      setInfluencerApps(influencerData.applications || [])
      setJobApps(jobData.applications || [])
    } catch (error) {
      console.error('Error fetching applications:', error)
    } finally {
      setLoading(false)
    }
  }

  const downloadCSV = (applications: Application[], filename: string) => {
    if (applications.length === 0) return
    
    const headers = Object.keys(applications[0]).filter(key => key !== 'id')
    const csvContent = [
      headers.join(','),
      ...applications.map(app => 
        headers.map(header => {
          const value = app[header]
          return typeof value === 'string' && value.includes(',') 
            ? `"${value}"` 
            : value
        }).join(',')
      )
    ].join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading applications...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-primary">PalverseMedia Admin</div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={fetchApplications}>
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{influencerApps.length + jobApps.length}</div>
              <p className="text-xs text-muted-foreground">
                All time applications
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Influencer Apps</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{influencerApps.length}</div>
              <p className="text-xs text-muted-foreground">
                Creator applications
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Job Apps</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{jobApps.length}</div>
              <p className="text-xs text-muted-foreground">
                Job applications
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {influencerApps.filter(app => app.status === 'pending').length + 
                 jobApps.filter(app => app.status === 'pending').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Awaiting review
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Influencer Applications */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">Influencer Applications</h2>
            <Button 
              variant="outline" 
              onClick={() => downloadCSV(influencerApps, 'influencer-applications.csv')}
              disabled={influencerApps.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Download CSV
            </Button>
          </div>
          
          <div className="grid gap-6">
            {influencerApps.map((app) => (
              <Card key={app.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarFallback>{app.firstName[0]}{app.lastName[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{app.firstName} {app.lastName}</CardTitle>
                        <CardDescription className="flex items-center space-x-2 mt-1">
                          <Mail className="w-4 h-4" />
                          <span>{app.email}</span>
                          <Phone className="w-4 h-4 ml-2" />
                          <span>{app.phone}</span>
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={app.status === 'pending' ? 'secondary' : 'default'}>
                        {app.status}
                      </Badge>
                      <Badge variant="outline">{app.city}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Platform:</span>
                      <p className="text-muted-foreground capitalize">{app.primaryPlatform}</p>
                    </div>
                    <div>
                      <span className="font-medium">Followers:</span>
                      <p className="text-muted-foreground">{app.followers?.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="font-medium">Niche:</span>
                      <p className="text-muted-foreground capitalize">{app.niche}</p>
                    </div>
                    <div>
                      <span className="font-medium">Experience:</span>
                      <p className="text-muted-foreground">{app.experience} months</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <span className="font-medium">Profile:</span>
                    <a href={app.profileLink} target="_blank" rel="noopener noreferrer" 
                       className="text-primary hover:underline ml-2">
                      View Profile
                    </a>
                  </div>
                  <div className="mt-2">
                    <span className="font-medium">Applied:</span>
                    <span className="text-muted-foreground ml-2">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {influencerApps.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No influencer applications yet</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Job Applications */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">Job Applications</h2>
            <Button 
              variant="outline" 
              onClick={() => downloadCSV(jobApps, 'job-applications.csv')}
              disabled={jobApps.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Download CSV
            </Button>
          </div>
          
          <div className="grid gap-6">
            {jobApps.map((app) => (
              <Card key={app.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarFallback>{app.firstName[0]}{app.lastName[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{app.firstName} {app.lastName}</CardTitle>
                        <CardDescription className="flex items-center space-x-2 mt-1">
                          <Mail className="w-4 h-4" />
                          <span>{app.email}</span>
                          <Phone className="w-4 h-4 ml-2" />
                          <span>{app.phone}</span>
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={app.status === 'pending' ? 'secondary' : 'default'}>
                        {app.status}
                      </Badge>
                      <Badge variant="outline">{app.city}</Badge>
                      <Badge variant="secondary">{app.jobTitle}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Education:</span>
                      <p className="text-muted-foreground capitalize">{app.education}</p>
                    </div>
                    <div>
                      <span className="font-medium">Experience:</span>
                      <p className="text-muted-foreground">{app.experience} months</p>
                    </div>
                    <div>
                      <span className="font-medium">Skills:</span>
                      <p className="text-muted-foreground">{app.skills?.substring(0, 50)}...</p>
                    </div>
                    <div>
                      <span className="font-medium">Resume:</span>
                      {app.resume ? (
                        <a href={app.resume} target="_blank" rel="noopener noreferrer" 
                           className="text-primary hover:underline block">
                          View Resume
                        </a>
                      ) : (
                        <p className="text-muted-foreground">Not provided</p>
                      )}
                    </div>
                  </div>
                  <div className="mt-4">
                    <span className="font-medium">Background:</span>
                    <p className="text-muted-foreground mt-1">{app.background?.substring(0, 150)}...</p>
                  </div>
                  <div className="mt-2">
                    <span className="font-medium">Applied:</span>
                    <span className="text-muted-foreground ml-2">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {jobApps.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <Briefcase className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No job applications yet</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}