"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, Users, TrendingUp, Star, Award, Target, MessageSquare, Heart, Phone, Calendar, Video, Edit, Instagram, Facebook, Youtube, Play, X } from "lucide-react"
import { useState } from "react"

export default function Home() {
  const [showInfluencerForm, setShowInfluencerForm] = useState(false)
  const [showJobForm, setShowJobForm] = useState(false)
  const [selectedJob, setSelectedJob] = useState("")

  const handleInfluencerSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const data = Object.fromEntries(formData)
    
    try {
      const response = await fetch('/api/influencer-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      
      if (response.ok) {
        alert('Application submitted successfully!')
        setShowInfluencerForm(false)
      }
    } catch (error) {
      alert('Error submitting application')
    }
  }

  const handleJobSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const data = Object.fromEntries(formData)
    data.jobTitle = selectedJob
    
    try {
      const response = await fetch('/api/job-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      
      if (response.ok) {
        alert('Application submitted successfully!')
        setShowJobForm(false)
        setSelectedJob("")
      }
    } catch (error) {
      alert('Error submitting application')
    }
  }
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background/95 to-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-primary">PalverseMedia</div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#offerings" className="text-muted-foreground hover:text-primary transition-colors">Offerings</a>
              <a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="#why-choose" className="text-muted-foreground hover:text-primary transition-colors">Why Choose Us</a>
              <a href="#testimonials" className="text-muted-foreground hover:text-primary transition-colors">Testimonials</a>
              <a href="#influencer-form" className="text-muted-foreground hover:text-primary transition-colors">Join as Influencer</a>
              <a href="/about" className="text-muted-foreground hover:text-primary transition-colors">About Us</a>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => setShowInfluencerForm(true)}>Join Us Now</Button>
              <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
                <Button>Book a Call</Button>
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-32 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-primary/10 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-primary/10 to-transparent rounded-full blur-3xl"></div>
        
        <div className="container mx-auto text-center relative z-10">
          <Badge variant="secondary" className="mb-6 text-sm px-4 py-2 bg-primary/10 text-primary border-primary/20">
            ✨ Premium Influencer Marketing Agency
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
            <span className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              Elevate Your Brand
            </span>
            <br />
            <span className="text-foreground">With Authentic</span>
            <br />
            <span className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              Influencer Partnerships
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-4xl mx-auto leading-relaxed">
            PalverseMedia crafts sophisticated influencer marketing strategies that transcend traditional advertising. 
            We connect premium brands with exceptional creators to deliver measurable, authentic growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="text-lg px-12 py-4 bg-primary hover:bg-primary/90 transition-all duration-300 shadow-lg hover:shadow-xl">
                <Phone className="w-5 h-5 mr-2" />
                Book a Strategy Call
              </Button>
            </a>
            <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="text-lg px-12 py-4 border-primary/20 hover:border-primary/40 transition-all duration-300">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule a Demo
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Offerings Section */}
      <section id="offerings" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <Badge variant="secondary" className="mb-4">Our Premium Services</Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                What We Do
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive digital marketing solutions crafted with precision and creativity
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="group border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-background to-primary/5 hover:to-primary/10">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="text-xl font-bold">Influencer Marketing</CardTitle>
                <CardDescription className="text-base">
                  Strategic partnerships with premium influencers to amplify your brand message and drive authentic engagement.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-background to-primary/5 hover:to-primary/10">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Video className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="text-xl font-bold">UGC Videos</CardTitle>
                <CardDescription className="text-base">
                  Authentic user-generated content that builds trust and converts viewers into loyal customers.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-background to-primary/5 hover:to-primary/10">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Instagram className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="text-xl font-bold">Social Media Management</CardTitle>
                <CardDescription className="text-base">
                  End-to-end social media strategy and management to build your digital presence and community.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group border-0 shadow-xl hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-background to-primary/5 hover:to-primary/10">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Edit className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="text-xl font-bold">Video Editing</CardTitle>
                <CardDescription className="text-base">
                  Professional video editing services that transform raw footage into compelling visual stories.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          <div className="text-center mt-16">
            <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="px-12 py-4 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all duration-300 shadow-xl">
                <Phone className="w-5 h-5 mr-2" />
                Discuss Your Requirements
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Why Choose PalverseMedia Section */}
      <section id="why-choose" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-muted/30 to-background">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <Badge variant="secondary" className="mb-4">Why Partner With Us</Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              The PalverseMedia
              <br />
              <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                Advantage
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Discover why leading brands choose our proven methodologies for exceptional results
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-16">
            {/* Influencer Marketing Roadmap */}
            <Card className="border-0 shadow-2xl bg-gradient-to-br from-background to-primary/5">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold ml-4">Influencer Marketing Excellence</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Our comprehensive approach to influencer marketing delivers unmatched results
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Strategic Creator Selection</h4>
                      <p className="text-muted-foreground text-sm">AI-powered matching with creators who align with your brand values and target audience demographics.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Campaign Strategy Development</h4>
                      <p className="text-muted-foreground text-sm">Custom campaign briefs with clear objectives, KPIs, and creative direction for maximum impact.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Content Creation & Approval</h4>
                      <p className="text-muted-foreground text-sm">Collaborative content creation process with quality assurance and brand alignment checks.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Performance Analytics & Optimization</h4>
                      <p className="text-muted-foreground text-sm">Real-time tracking, comprehensive analytics, and continuous optimization for better ROI.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* UGC Videos Roadmap */}
            <Card className="border-0 shadow-2xl bg-gradient-to-br from-background to-primary/5">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center">
                    <Video className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold ml-4">UGC Video Production</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Authentic user-generated content that builds trust and drives conversions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Creator Network Activation</h4>
                      <p className="text-muted-foreground text-sm">Access to our curated network of content creators specializing in authentic, relatable content.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Content Brief & Direction</h4>
                      <p className="text-muted-foreground text-sm">Detailed creative briefs that maintain authenticity while delivering your brand message effectively.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Professional Production Quality</h4>
                      <p className="text-muted-foreground text-sm">High-quality filming, editing, and post-production to ensure premium content standards.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Multi-Platform Distribution</h4>
                      <p className="text-muted-foreground text-sm">Strategic distribution across relevant platforms to maximize reach and engagement.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Social Media Management Roadmap */}
            <Card className="border-0 shadow-2xl bg-gradient-to-br from-background to-primary/5">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center">
                    <Instagram className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold ml-4">Social Media Management</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Comprehensive social media strategy and execution for brand growth
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Audit & Strategy Development</h4>
                      <p className="text-muted-foreground text-sm">Comprehensive social media audit and customized strategy development based on your goals.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Content Calendar Creation</h4>
                      <p className="text-muted-foreground text-sm">Strategic content planning with engaging posts, stories, and interactive content schedules.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Community Management</h4>
                      <p className="text-muted-foreground text-sm">Active community engagement, response management, and relationship building with your audience.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Analytics & Reporting</h4>
                      <p className="text-muted-foreground text-sm">Detailed performance analytics, insights, and regular reporting with actionable recommendations.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Video Editing Roadmap */}
            <Card className="border-0 shadow-2xl bg-gradient-to-br from-background to-primary/5">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center">
                    <Edit className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold ml-4">Professional Video Editing</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Transform raw footage into compelling visual stories
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Raw Footage Assessment</h4>
                      <p className="text-muted-foreground text-sm">Professional evaluation of all footage to identify the best shots and storytelling opportunities.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Creative Editing & Assembly</h4>
                      <p className="text-muted-foreground text-sm">Expert editing with seamless transitions, proper pacing, and compelling narrative structure.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Color Grading & Enhancement</h4>
                      <p className="text-muted-foreground text-sm">Professional color correction and grading to achieve the perfect visual aesthetic.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Sound Design & Final Delivery</h4>
                      <p className="text-muted-foreground text-sm">Professional audio mixing, sound design, and final delivery in optimal formats for all platforms.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-16">
            <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="px-12 py-4 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all duration-300 shadow-xl">
                <Phone className="w-5 h-5 mr-2" />
                Schedule Your Free Consultation
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose PalverseMedia?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our platform combines cutting-edge technology with human expertise to deliver exceptional results.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Smart Matching</CardTitle>
                <CardDescription>
                  Our AI-powered algorithm connects brands with the perfect influencers based on audience demographics, engagement rates, and brand values.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Real-time Analytics</CardTitle>
                <CardDescription>
                  Track campaign performance with comprehensive analytics including reach, engagement, conversions, and ROI in real-time.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Seamless Communication</CardTitle>
                <CardDescription>
                  Built-in messaging and collaboration tools make it easy to manage campaigns, share briefs, and maintain clear communication.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Campaign Management</CardTitle>
                <CardDescription>
                  From brief creation to content approval and payment processing, manage every aspect of your influencer campaigns in one place.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Community Building</CardTitle>
                <CardDescription>
                  Build long-term relationships with influencers and create authentic brand communities that drive sustained growth.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Award className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Quality Assurance</CardTitle>
                <CardDescription>
                  All influencers are vetted for authenticity, engagement quality, and professional standards to ensure campaign success.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-muted/50 to-background">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How PalverseMedia Works</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              A simple, streamlined process for brands and influencers to collaborate effectively.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-6">For Brands</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">1</div>
                  <div>
                    <h4 className="font-semibold mb-2">Create Campaign Brief</h4>
                    <p className="text-muted-foreground">Define your goals, target audience, budget, and content requirements.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">2</div>
                  <div>
                    <h4 className="font-semibold mb-2">Get Matched</h4>
                    <p className="text-muted-foreground">Our AI suggests perfect influencers based on your campaign needs.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">3</div>
                  <div>
                    <h4 className="font-semibold mb-2">Collaborate & Create</h4>
                    <p className="text-muted-foreground">Work with influencers to create authentic, engaging content.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">4</div>
                  <div>
                    <h4 className="font-semibold mb-2">Track & Optimize</h4>
                    <p className="text-muted-foreground">Monitor performance and optimize campaigns in real-time.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-semibold mb-6">For Influencers</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">1</div>
                  <div>
                    <h4 className="font-semibold mb-2">Create Your Profile</h4>
                    <p className="text-muted-foreground">Showcase your audience, niche, and past collaborations.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">2</div>
                  <div>
                    <h4 className="font-semibold mb-2">Discover Campaigns</h4>
                    <p className="text-muted-foreground">Browse and apply for campaigns that match your style and audience.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">3</div>
                  <div>
                    <h4 className="font-semibold mb-2">Create & Submit</h4>
                    <p className="text-muted-foreground">Create authentic content and submit for brand approval.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">4</div>
                  <div>
                    <h4 className="font-semibold mb-2">Get Paid & Grow</h4>
                    <p className="text-muted-foreground">Receive timely payments and build your portfolio.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Real results from real brands and influencers who trust PalverseMedia.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">
                  "PalverseMedia helped us reach 2 million new customers in just 3 months. The influencer matching was perfect for our brand!"
                </p>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" />
                    <AvatarFallback>SJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">Sarah Johnson</p>
                    <p className="text-sm text-muted-foreground">Marketing Director, TechCorp</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">
                  "As a micro-influencer, I've doubled my income and worked with amazing brands that truly align with my values."
                </p>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" />
                    <AvatarFallback>MC</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">Mike Chen</p>
                    <p className="text-sm text-muted-foreground">Lifestyle Influencer</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">
                  "The analytics dashboard is incredible. We can see exactly how each campaign performs and optimize in real-time."
                </p>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" />
                    <AvatarFallback>AL</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">Alex Lee</p>
                    <p className="text-sm text-muted-foreground">CEO, BeautyBrand</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Influencer Form Section */}
      <section id="influencer-form" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-muted/50 to-background">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Join Our Creator Network</Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                Become a PalverseMedia Creator
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              We're always looking for talented creators to collaborate with our premium brand partners. 
              Fill out the form and we'll connect with you when campaigns match your unique style and audience.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Form on the left */}
            <div>
              <Card className="border-0 shadow-2xl bg-gradient-to-br from-background to-primary/5">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-center">Creator Application</CardTitle>
                  <CardDescription className="text-center">
                    Tell us about yourself and we'll reach out when we have campaigns that match your profile
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="inf-name" className="block text-sm font-medium mb-2">Full Name</label>
                        <input 
                          id="inf-name" 
                          type="text" 
                          placeholder="Your full name" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        />
                      </div>
                      <div>
                        <label htmlFor="inf-email" className="block text-sm font-medium mb-2">Email Address</label>
                        <input 
                          id="inf-email" 
                          type="email" 
                          placeholder="your@email.com" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        />
                      </div>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="inf-phone" className="block text-sm font-medium mb-2">Phone Number</label>
                        <input 
                          id="inf-phone" 
                          type="tel" 
                          placeholder="+91 98765 43210" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        />
                      </div>
                      <div>
                        <label htmlFor="inf-location" className="block text-sm font-medium mb-2">City</label>
                        <input 
                          id="inf-location" 
                          type="text" 
                          placeholder="Your city" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="inf-platform" className="block text-sm font-medium mb-2">Primary Social Media Platform</label>
                      <select 
                        id="inf-platform" 
                        className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                      >
                        <option value="">Select your main platform</option>
                        <option value="instagram">Instagram</option>
                        <option value="youtube">YouTube</option>
                        <option value="tiktok">TikTok</option>
                        <option value="linkedin">LinkedIn</option>
                        <option value="twitter">Twitter/X</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="inf-followers" className="block text-sm font-medium mb-2">Number of Followers</label>
                        <select 
                          id="inf-followers" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        >
                          <option value="">Select range</option>
                          <option value="1k-10k">1K - 10K</option>
                          <option value="10k-50k">10K - 50K</option>
                          <option value="50k-100k">50K - 100K</option>
                          <option value="100k-500k">100K - 500K</option>
                          <option value="500k+">500K+</option>
                        </select>
                      </div>
                      <div>
                        <label htmlFor="inf-niche" className="block text-sm font-medium mb-2">Content Niche</label>
                        <select 
                          id="inf-niche" 
                          className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200"
                        >
                          <option value="">Select your niche</option>
                          <option value="fashion">Fashion & Beauty</option>
                          <option value="lifestyle">Lifestyle</option>
                          <option value="tech">Technology</option>
                          <option value="food">Food & Dining</option>
                          <option value="travel">Travel</option>
                          <option value="fitness">Fitness & Health</option>
                          <option value="entertainment">Entertainment</option>
                          <option value="education">Education</option>
                          <option value="business">Business & Finance</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="inf-portfolio" className="block text-sm font-medium mb-2">Portfolio/Profile Links</label>
                      <textarea 
                        id="inf-portfolio" 
                        placeholder="Share links to your social media profiles, portfolio, or previous work..." 
                        className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200 min-h-[100px]"
                      ></textarea>
                    </div>
                    
                    <div>
                      <label htmlFor="inf-message" className="block text-sm font-medium mb-2">Tell us about yourself</label>
                      <textarea 
                        id="inf-message" 
                        placeholder="Why do you want to work with PalverseMedia? What makes you unique as a creator?" 
                        className="w-full px-4 py-3 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-200 min-h-[100px]"
                      ></textarea>
                    </div>
                    
                    <Button type="submit" className="w-full py-3 text-lg bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all duration-300">
                      Submit Application
                    </Button>
                    
                    <p className="text-sm text-muted-foreground text-center">
                      We'll review your application and contact you when we have campaigns that match your profile
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Graphics on the right */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent rounded-3xl blur-3xl"></div>
              <div className="relative bg-gradient-to-br from-primary/5 to-background rounded-3xl p-8 h-full">
                <div className="text-center mb-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Users className="w-12 h-12 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Join Our Elite Creator Network</h3>
                  <p className="text-muted-foreground">
                    Connect with premium brands and create authentic content that drives real results
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Premium Brand Partnerships</h4>
                      <p className="text-sm text-muted-foreground">Work with high-quality brands that value authentic content</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Competitive Compensation</h4>
                      <p className="text-sm text-muted-foreground">Fair pay for your creativity and influence</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Professional Growth</h4>
                      <p className="text-sm text-muted-foreground">Build your portfolio and grow your personal brand</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Target className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Creative Freedom</h4>
                      <p className="text-sm text-muted-foreground">Express your unique style while meeting brand objectives</p>
                    </div>
                  </div>
                </div>

                <div className="mt-12 text-center">
                  <div className="inline-flex items-center space-x-2 text-primary">
                    <Phone className="w-5 h-5" />
                    <span className="font-medium">Questions?</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Contact our creator support team at hello@palversemedia.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-muted/50">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="group">
              <div className="text-5xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">10K+</div>
              <div className="text-muted-foreground">Active Influencers</div>
            </div>
            <div className="group">
              <div className="text-5xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">2M+</div>
              <div className="text-muted-foreground">Campaigns Completed</div>
            </div>
            <div className="group">
              <div className="text-5xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">$50M+</div>
              <div className="text-muted-foreground">Revenue Generated</div>
            </div>
            <div className="group">
              <div className="text-5xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">98%</div>
              <div className="text-muted-foreground">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Transform Your Marketing?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Join thousands of brands and influencers who are already achieving remarkable results with PalverseMedia.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-12 py-4 bg-white text-primary hover:bg-white/90 transition-all duration-300 shadow-xl">
              <Phone className="w-5 h-5 mr-2" />
              Book a Strategy Call
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-12 py-4 border-white text-white hover:bg-white hover:text-primary transition-all duration-300">
              <Calendar className="w-5 h-5 mr-2" />
              Schedule a Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-5 gap-8">
            <div>
              <div className="text-2xl font-bold text-primary mb-4">PalverseMedia</div>
              <p className="text-muted-foreground mb-4">
                Connecting brands with influencers for authentic marketing that drives results.
              </p>
              <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" size="sm" className="w-full">
                  <Phone className="w-4 h-4 mr-2" />
                  Book a Call
                </Button>
              </a>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Brands</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#offerings" className="hover:text-primary transition-colors">Our Services</a></li>
                <li><a href="#why-choose" className="hover:text-primary transition-colors">Why Choose Us</a></li>
                <li><a href="#features" className="hover:text-primary transition-colors">Features</a></li>
                <li><a href="#testimonials" className="hover:text-primary transition-colors">Success Stories</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Influencers</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#influencer-form" className="hover:text-primary transition-colors">Join as Creator</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Guidelines</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Payment Info</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="/about" className="hover:text-primary transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>📧 hello@palversemedia.com</li>
                <li>📞 +91 73039 19615</li>
                <li>📍 Kolkata, India</li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-12 pt-8 text-center text-muted-foreground">
            <p>© 2024 PalverseMedia. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Influencer Application Modal */}
      {showInfluencerForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-2xl font-bold">Join as Influencer</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowInfluencerForm(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            <form onSubmit={handleInfluencerSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input id="firstName" name="firstName" required placeholder="John" />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input id="lastName" name="lastName" required placeholder="Doe" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" name="email" type="email" required placeholder="john@example.com" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" name="phone" required placeholder="+91 98765 43210" />
                </div>
              </div>
              
              <div>
                <Label htmlFor="city">City *</Label>
                <Input id="city" name="city" required placeholder="Kolkata" />
              </div>
              
              <div>
                <Label htmlFor="primaryPlatform">Primary Platform *</Label>
                <Select name="primaryPlatform" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your primary platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="twitter">Twitter</SelectItem>
                    <SelectItem value="linkedin">LinkedIn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="followers">Followers *</Label>
                  <Input id="followers" name="followers" type="number" required placeholder="10000" />
                </div>
                <div>
                  <Label htmlFor="engagement">Engagement Rate %</Label>
                  <Input id="engagement" name="engagement" type="number" step="0.1" placeholder="3.5" />
                </div>
                <div>
                  <Label htmlFor="niche">Primary Niche *</Label>
                  <Select name="niche" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select niche" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fashion">Fashion</SelectItem>
                      <SelectItem value="beauty">Beauty</SelectItem>
                      <SelectItem value="fitness">Fitness</SelectItem>
                      <SelectItem value="food">Food</SelectItem>
                      <SelectItem value="travel">Travel</SelectItem>
                      <SelectItem value="tech">Technology</SelectItem>
                      <SelectItem value="lifestyle">Lifestyle</SelectItem>
                      <SelectItem value="gaming">Gaming</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="profileLink">Profile Link *</Label>
                <Input id="profileLink" name="profileLink" required placeholder="https://instagram.com/username" />
              </div>
              
              <div>
                <Label htmlFor="experience">Experience (months) *</Label>
                <Input id="experience" name="experience" type="number" required placeholder="6" />
              </div>
              
              <div>
                <Label htmlFor="bio">Bio / About You</Label>
                <Textarea id="bio" name="bio" placeholder="Tell us about yourself and your content..." className="min-h-[100px]" />
              </div>
              
              <div>
                <Label htmlFor="whyJoin">Why do you want to join PalverseMedia? *</Label>
                <Textarea id="whyJoin" name="whyJoin" required placeholder="Tell us why you're interested in joining..." className="min-h-[100px]" />
              </div>
              
              <Button type="submit" className="w-full">Submit Application</Button>
            </form>
          </div>
        </div>
      )}

      {/* Job Application Modal */}
      {showJobForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-2xl font-bold">Job Application - {selectedJob}</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowJobForm(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            <form onSubmit={handleJobSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="jobFirstName">First Name *</Label>
                  <Input id="jobFirstName" name="firstName" required placeholder="John" />
                </div>
                <div>
                  <Label htmlFor="jobLastName">Last Name *</Label>
                  <Input id="jobLastName" name="lastName" required placeholder="Doe" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="jobEmail">Email *</Label>
                  <Input id="jobEmail" name="email" type="email" required placeholder="john@example.com" />
                </div>
                <div>
                  <Label htmlFor="jobPhone">Phone *</Label>
                  <Input id="jobPhone" name="phone" required placeholder="+91 98765 43210" />
                </div>
              </div>
              
              <div>
                <Label htmlFor="jobCity">City *</Label>
                <Input id="jobCity" name="city" required placeholder="Kolkata" />
              </div>
              
              <div>
                <Label htmlFor="education">Highest Education *</Label>
                <Select name="education" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select education level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="diploma">Diploma</SelectItem>
                    <SelectItem value="bachelor">Bachelor's Degree</SelectItem>
                    <SelectItem value="master">Master's Degree</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="experience">Work Experience (months) *</Label>
                <Input id="experience" name="experience" type="number" required placeholder="6" />
              </div>
              
              <div>
                <Label htmlFor="skills">Key Skills *</Label>
                <Textarea id="skills" name="skills" required placeholder="List your key skills..." className="min-h-[80px]" />
              </div>
              
              <div>
                <Label htmlFor="background">Background / About You *</Label>
                <Textarea id="background" name="background" required placeholder="Tell us about your background..." className="min-h-[100px]" />
              </div>
              
              <div>
                <Label htmlFor="whyInterested">Why are you interested in this position? *</Label>
                <Textarea id="whyInterested" name="whyInterested" required placeholder="Tell us why you're interested..." className="min-h-[100px]" />
              </div>
              
              <div>
                <Label htmlFor="resume">Resume Link (Google Drive, Dropbox, etc.)</Label>
                <Input id="resume" name="resume" placeholder="https://drive.google.com/your-resume" />
              </div>
              
              <Button type="submit" className="w-full">Submit Application</Button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}