"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Globe, Users, Target, Award, Mail, Phone, MapPin, Briefcase, Star, X } from "lucide-react"
import { useState } from "react"

export default function AboutPage() {
  const [showJobForm, setShowJobForm] = useState(false)
  const [selectedJob, setSelectedJob] = useState("")

  const handleJobSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const data = Object.fromEntries(formData)
    data.jobTitle = selectedJob
    
    try {
      const response = await fetch('/api/job-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      
      if (response.ok) {
        alert('Application submitted successfully!')
        setShowJobForm(false)
        setSelectedJob("")
      }
    } catch (error) {
      alert('Error submitting application')
    }
  }
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-primary">PalverseMedia</div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
              <a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="#about" className="text-primary font-medium">About Us</a>
              <a href="#careers" className="text-muted-foreground hover:text-primary transition-colors">Careers</a>
              <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => {
                // Open influencer form - redirect to home page or implement form here
                window.location.href = '/#influencer-form';
              }}>Join Us Now</Button>
              <a href="https://calendly.com/palversemedia/30min" target="_blank" rel="noopener noreferrer">
                <Button>Book a Call</Button>
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4">About PalverseMedia</Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Your Growth Partners in
            <br />
            <span className="text-primary">Digital Innovation</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            We're not just another digital agency—we're your strategic partners in building authentic brand connections 
            through influencer marketing, UGC, and social media strategies that drive real results.
          </p>
        </div>
      </section>

      {/* Founder Section */}
      <section id="founder" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="flex items-center mb-6">
                <Badge variant="secondary" className="mr-3">Founder</Badge>
                <h2 className="text-3xl font-bold">Preetam</h2>
              </div>
              
              <div className="space-y-6">
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Preetam has been driving impact in the influencer marketing industry for <span className="font-semibold text-primary">6+ years</span>. 
                  His journey has taken him from India to various international markets, and he has built 
                  some of the most successful creator-brand collaborations from <span className="font-semibold text-primary">Kolkata, India</span>.
                </p>
                
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Over the years, he has worked with <span className="font-semibold text-primary">3,000+ influencers</span> across multiple industries, 
                  helping brands tell their stories with authenticity and scale their presence.
                </p>
                
                <p className="text-lg text-muted-foreground leading-relaxed">
                  With a deep understanding of both creators and brands, Preetam is passionate about building campaigns that 
                  deliver results while creating long-term relationships.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-8">
                <Card className="text-center">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-primary">6+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-primary">3K+</div>
                    <div className="text-sm text-muted-foreground">Influencers</div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-primary">3</div>
                    <div className="text-sm text-muted-foreground">Countries</div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="flex justify-center">
              <div className="relative">
                <div className="w-80 h-80 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full flex items-center justify-center">
                  <div className="w-72 h-72 bg-background rounded-full flex items-center justify-center overflow-hidden border-4 border-primary/10">
                    <img 
                      src="https://z-cdn-media.chatglm.cn/files/d539f9ae-10ce-4e57-b548-66a4c23d8385_Gemini_Generated_Image_jmqmr5jmqmr5jmqm.png?auth_key=1789596599-4efcce485527457f95457c847b385882-0-ac9883a56bd18b56e4dd9514244e9103"
                      alt="Preetam - Founder of PalverseMedia"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        // Fallback to initials if image fails to load
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        const parent = target.parentElement;
                        if (parent) {
                          const fallback = document.createElement('div');
                          fallback.className = 'w-full h-full flex items-center justify-center text-4xl font-bold text-primary';
                          fallback.textContent = 'P';
                          parent.appendChild(fallback);
                        }
                      }}
                    />
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-primary text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg">
                  Founder & CEO
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Performance Metrics Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Impact & Results</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Transforming Brands, Delivering Excellence</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Measurable success across campaigns and partnerships
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Metrics Cards */}
            <div className="grid grid-cols-2 gap-6">
              <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">300%</div>
                  <div className="text-sm text-muted-foreground mb-1">Average Brand Growth</div>
                  <div className="w-full bg-primary/10 rounded-full h-2 mt-3">
                    <div className="bg-primary h-2 rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">2000+</div>
                  <div className="text-sm text-muted-foreground mb-1">Successful Campaigns</div>
                  <div className="w-full bg-primary/10 rounded-full h-2 mt-3">
                    <div className="bg-primary h-2 rounded-full" style={{ width: '95%' }}></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">10M+</div>
                  <div className="text-sm text-muted-foreground mb-1">Reach Generated</div>
                  <div className="w-full bg-primary/10 rounded-full h-2 mt-3">
                    <div className="bg-primary h-2 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">98%</div>
                  <div className="text-sm text-muted-foreground mb-1">Client Satisfaction</div>
                  <div className="w-full bg-primary/10 rounded-full h-2 mt-3">
                    <div className="bg-primary h-2 rounded-full" style={{ width: '98%' }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Growth Chart Visualization */}
            <Card className="border-0 shadow-lg p-8">
              <CardHeader className="px-0 pt-0">
                <CardTitle className="text-2xl font-bold">Campaign Success Rate</CardTitle>
                <CardDescription>Performance metrics over the past 6 years</CardDescription>
              </CardHeader>
              <CardContent className="px-0">
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Influencer Marketing</span>
                      <span className="text-sm text-muted-foreground">95%</span>
                    </div>
                    <div className="w-full bg-primary/10 rounded-full h-3">
                      <div className="bg-gradient-to-r from-primary to-primary/80 h-3 rounded-full transition-all duration-1000" style={{ width: '95%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">UGC Content Creation</span>
                      <span className="text-sm text-muted-foreground">92%</span>
                    </div>
                    <div className="w-full bg-primary/10 rounded-full h-3">
                      <div className="bg-gradient-to-r from-primary to-primary/80 h-3 rounded-full transition-all duration-1000" style={{ width: '92%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Social Media Strategy</span>
                      <span className="text-sm text-muted-foreground">88%</span>
                    </div>
                    <div className="w-full bg-primary/10 rounded-full h-3">
                      <div className="bg-gradient-to-r from-primary to-primary/80 h-3 rounded-full transition-all duration-1000" style={{ width: '88%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Brand Partnerships</span>
                      <span className="text-sm text-muted-foreground">96%</span>
                    </div>
                    <div className="w-full bg-primary/10 rounded-full h-3">
                      <div className="bg-gradient-to-r from-primary to-primary/80 h-3 rounded-full transition-all duration-1000" style={{ width: '96%' }}></div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Overall Success Rate</span>
                      <span className="text-2xl font-bold text-primary">92.75%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Company Story Section */}
      <section id="company" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Story</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Born out of a passion for storytelling and digital innovation
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="w-6 h-6 mr-2 text-primary" />
                    Our Mission
                  </CardTitle>
                  <CardDescription className="text-base">
                    At Palverse Media, we're not just another digital agency—we're your growth partners. We specialize in 
                    Influencer Marketing, UGC, and Social Media Strategies that don't just look good on paper, but actually 
                    drive brand awareness, engagement, and sales.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>

            <div>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-6 h-6 mr-2 text-primary" />
                    Our Vision
                  </CardTitle>
                  <CardDescription className="text-base">
                    Founded to bridge the gap between brands and creators. We believe every brand has a unique voice, and 
                    our job is to amplify it in the most authentic way possible.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Careers Section */}
      <section id="careers" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Team</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Be part of a dynamic team that's shaping the future of influencer marketing
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary">Full-time</Badge>
                  <Badge variant="outline">₹10,000/month</Badge>
                </div>
                <CardTitle className="flex items-center">
                  <Briefcase className="w-5 h-5 mr-2 text-primary" />
                  Influencer Marketing Sales (BD)
                </CardTitle>
                <CardDescription>
                  We're looking for a driven Business Development professional to help us expand our client base and build 
                  strong relationships with brands looking for influencer marketing solutions.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Key Responsibilities:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Identify and onboard new brand clients</li>
                    <li>• Build and maintain client relationships</li>
                    <li>• Present our services and close deals</li>
                    <li>• Meet monthly revenue targets</li>
                  </ul>
                </div>
                <Button 
                  className="w-full mt-4" 
                  onClick={() => {
                    setSelectedJob("Influencer Marketing Sales (BD)")
                    setShowJobForm(true)
                  }}
                >
                  Apply Now
                </Button>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary">Full-time</Badge>
                  <Badge variant="outline">₹5,000/month</Badge>
                </div>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-primary" />
                  Influencer Marketing Executive
                </CardTitle>
                <CardDescription>
                  Join our team as an Influencer Marketing Executive and help manage campaigns, coordinate with creators, 
                  and ensure successful delivery of marketing campaigns.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Key Responsibilities:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Manage influencer campaigns from start to finish</li>
                    <li>• Coordinate with creators and brands</li>
                    <li>• Track campaign performance and report results</li>
                    <li>• Freshers with 0-6 months experience welcome</li>
                  </ul>
                </div>
                <Button 
                  className="w-full mt-4" 
                  onClick={() => {
                    setSelectedJob("Influencer Marketing Executive")
                    setShowJobForm(true)
                  }}
                >
                  Apply Now
                </Button>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary">Full-time</Badge>
                  <Badge variant="outline">₹5,000/month</Badge>
                </div>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2 text-primary" />
                  Social Media Manager & Content Creator
                </CardTitle>
                <CardDescription>
                  We're seeking a creative Social Media Manager who can also create compelling content. Manage our social 
                  presence and create engaging content for our brands.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Key Responsibilities:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Manage social media accounts for multiple brands</li>
                    <li>• Create engaging content (graphics, videos, copy)</li>
                    <li>• Develop content calendars and strategies</li>
                    <li>• Freshers with 0-6 months experience welcome</li>
                  </ul>
                </div>
                <Button 
                  className="w-full mt-4" 
                  onClick={() => {
                    setSelectedJob("Social Media Manager & Content Creator")
                    setShowJobForm(true)
                  }}
                >
                  Apply Now
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">
              All positions are open to freshers with 0-6 months experience
            </p>
            <Button variant="outline" size="lg">
              Send Your Resume to: hello@palversemedia.com
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Ready to transform your brand through authentic influencer marketing?
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                  <CardDescription>
                    Reach out to us and let's discuss how we can help your brand grow
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-muted-foreground">hello@palversemedia.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-muted-foreground">+91 73039 19615</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-muted-foreground">Kolkata, India</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Send us a Message</CardTitle>
                  <CardDescription>
                    Fill out the form below and we'll get back to you as soon as possible
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" placeholder="John" />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" placeholder="Doe" />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="john@example.com" />
                    </div>
                    
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" placeholder="+91 98765 43210" />
                    </div>
                    
                    <div>
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" placeholder="Your Company Name" />
                    </div>
                    
                    <div>
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" placeholder="Tell us about your project..." className="min-h-[100px]" />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold text-primary mb-4">PalverseMedia</div>
              <p className="text-muted-foreground">
                Connecting brands with influencers for authentic marketing that drives results.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Brands</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary">How it Works</a></li>
                <li><a href="#" className="hover:text-primary">Pricing</a></li>
                <li><a href="#" className="hover:text-primary">Success Stories</a></li>
                <li><a href="#" className="hover:text-primary">Resources</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Influencers</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Join as Creator</a></li>
                <li><a href="#" className="hover:text-primary">Guidelines</a></li>
                <li><a href="#" className="hover:text-primary">Payment Info</a></li>
                <li><a href="#" className="hover:text-primary">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="/about" className="hover:text-primary">About Us</a></li>
                <li><a href="#careers" className="hover:text-primary">Careers</a></li>
                <li><a href="#" className="hover:text-primary">Blog</a></li>
                <li><a href="#contact" className="hover:text-primary">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>© 2024 PalverseMedia. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Job Application Modal */}
      {showJobForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-2xl font-bold">Job Application - {selectedJob}</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowJobForm(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            <form onSubmit={handleJobSubmit} className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="jobFirstName">First Name *</Label>
                  <Input id="jobFirstName" name="firstName" required placeholder="John" />
                </div>
                <div>
                  <Label htmlFor="jobLastName">Last Name *</Label>
                  <Input id="jobLastName" name="lastName" required placeholder="Doe" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="jobEmail">Email *</Label>
                  <Input id="jobEmail" name="email" type="email" required placeholder="john@example.com" />
                </div>
                <div>
                  <Label htmlFor="jobPhone">Phone *</Label>
                  <Input id="jobPhone" name="phone" required placeholder="+91 98765 43210" />
                </div>
              </div>
              
              <div>
                <Label htmlFor="jobCity">City *</Label>
                <Input id="jobCity" name="city" required placeholder="Kolkata" />
              </div>
              
              <div>
                <Label htmlFor="education">Highest Education *</Label>
                <Select name="education" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select education level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="diploma">Diploma</SelectItem>
                    <SelectItem value="bachelor">Bachelor's Degree</SelectItem>
                    <SelectItem value="master">Master's Degree</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="experience">Work Experience (months) *</Label>
                <Input id="experience" name="experience" type="number" required placeholder="6" />
              </div>
              
              <div>
                <Label htmlFor="skills">Key Skills *</Label>
                <Textarea id="skills" name="skills" required placeholder="List your key skills..." className="min-h-[80px]" />
              </div>
              
              <div>
                <Label htmlFor="background">Background / About You *</Label>
                <Textarea id="background" name="background" required placeholder="Tell us about your background..." className="min-h-[100px]" />
              </div>
              
              <div>
                <Label htmlFor="whyInterested">Why are you interested in this position? *</Label>
                <Textarea id="whyInterested" name="whyInterested" required placeholder="Tell us why you're interested..." className="min-h-[100px]" />
              </div>
              
              <div>
                <Label htmlFor="resume">Resume Link (Google Drive, Dropbox, etc.)</Label>
                <Input id="resume" name="resume" placeholder="https://drive.google.com/your-resume" />
              </div>
              
              <Button type="submit" className="w-full">Submit Application</Button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}